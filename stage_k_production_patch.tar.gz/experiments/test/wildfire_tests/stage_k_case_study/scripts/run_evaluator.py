from experiments.test.wildfire_tests.stage_k_case_study.src.evaluator_runner import main

if __name__ == "__main__":
    raise SystemExit(main())
