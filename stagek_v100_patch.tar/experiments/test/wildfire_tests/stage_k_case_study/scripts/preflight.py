"""Stage K input, CPU, and A100 preflight entry point."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import tempfile
import traceback

from experiments.test.wildfire_tests.stage_k_case_study.src.baseline_audit import run_audit
from experiments.test.wildfire_tests.stage_k_case_study.src.gridsfm_adapter import build_raw_gridsfm_case
from experiments.test.wildfire_tests.stage_k_case_study.src.identity import build_identity
from experiments.test.wildfire_tests.stage_k_case_study.src.gridsfm_environment import (
    capture_gridsfm_environment,
)
from experiments.test.wildfire_tests.stage_k_case_study.src.io_utils import atomic_write_json
from experiments.test.wildfire_tests.stage_k_case_study.src.prepare_inputs import prepare
from experiments.test.wildfire_tests.stage_k_case_study.src.validate import validate_prepared


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["inputs", "cpu", "gpu", "all"], default="inputs")
    parser.add_argument("--config", required=True)
    parser.add_argument("--prepared-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--gridsfm-root")
    parser.add_argument("--checkpoint")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--environment-contract")
    parser.add_argument("--julia", default="julia")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    report: dict[str, object] = {"scope": args.scope, "checks": {}, "status": "PASS"}
    if args.scope in {"inputs", "all"}:
        report["input_manifest"] = prepare(args.config, args.prepared_dir)
        report["input_validation"] = validate_prepared(args.config, args.prepared_dir)
        report["checks"]["inputs"] = report["input_validation"]["status"] == "PASS"
    if args.scope in {"cpu", "all"}:
        report["checks"]["julia_found"] = shutil.which(args.julia) is not None
        if report["checks"]["julia_found"]:
            report["baseline_consistency_audit"] = run_audit(args.config, output / "baseline_audit", julia=args.julia)
            report["checks"]["baseline_consistency_audit"] = report["baseline_consistency_audit"]["status"] == "PASS"
    if args.scope in {"gpu", "all"}:
        if not args.gridsfm_root or not args.checkpoint:
            parser.error("GPU preflight requires --gridsfm-root and --checkpoint")
        environment_manifest_path = output / "gridsfm_environment_manifest.json"
        try:
            environment_manifest, environment_checks = capture_gridsfm_environment(
                args.gridsfm_root, args.checkpoint, device=args.device,
                **({"contract_path": args.environment_contract} if args.environment_contract else {}),
            )
            environment_manifest["checks"] = environment_checks
            environment_manifest["status"] = (
                "PASS" if all(environment_checks.values()) else "FAIL"
            )
            atomic_write_json(environment_manifest_path, environment_manifest)
            report["environment_manifest"] = str(environment_manifest_path.resolve())
            report["checks"].update(
                {f"environment_{key}": value for key, value in environment_checks.items()}
            )
            if environment_manifest["status"] == "PASS":
                from gridsfm import load_model, load_pyg_json, predict, prepare_for_inference

                identity = build_identity()
                raw = build_raw_gridsfm_case(identity)
                with tempfile.TemporaryDirectory() as temp:
                    sample = Path(temp) / "modifiedTexas2k_stage_k.pyg.json"
                    sample.write_text(json.dumps(raw), encoding="utf-8")
                    prepared = prepare_for_inference(load_pyg_json(sample))
                    report["prepared_shapes"] = {
                        node_type: list(prepared[node_type].x.shape) for node_type in prepared.node_types
                    }
                    model = load_model(str(Path(args.checkpoint).resolve()), device=args.device)
                    prediction = predict(model, str(sample))
                    report["prediction_shapes"] = {
                        key: list(value.shape) if hasattr(value, "shape") else None
                        for key, value in prediction.items()
                    }
                    report["checks"]["intact_inference"] = all(
                        key in prediction
                        for key in ("V", "theta", "Pg", "Pij", "Qij", "Pji", "Qji", "feas")
                    )
            else:
                report["checks"]["intact_inference"] = False
        except Exception as exc:
            failure = {
                "status": "FAIL",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
            atomic_write_json(environment_manifest_path, failure)
            report["environment_manifest"] = str(environment_manifest_path.resolve())
            report["checks"]["environment_capture"] = False
            report["checks"]["intact_inference"] = False
    if not all(bool(value) for value in report["checks"].values()):
        report["status"] = "FAIL"
    report["thread_environment"] = {
        key: os.environ.get(key, "")
        for key in ("JULIA_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")
    }
    preflight_name = "PREFLIGHT_PASS.json" if report["status"] == "PASS" else "PREFLIGHT_FAIL.json"
    atomic_write_json(output / preflight_name, report)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
